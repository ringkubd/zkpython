.. toctree::
   :caption: Device maintenance
   :name: topic4

##################
Device Maintenance
##################

Set Time
--------

Poweroff
--------

Restart
-------

Clear Buffer
------------

Clear Data
-----------

