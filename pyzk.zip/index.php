<?php 

ob_start();
passthru('/usr/bin/python2.7 /media/anwar/b972b4d0-d82b-405b-8e69-9c879f172d9f/pyzk-master/basic_test.py');
$output = ob_get_clean(); 
var_dump($output);
?>